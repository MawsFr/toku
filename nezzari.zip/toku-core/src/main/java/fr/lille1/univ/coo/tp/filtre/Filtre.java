package fr.lille1.univ.coo.tp.filtre;

public abstract class Filtre extends Visiteur<Boolean> {
	
	
}
