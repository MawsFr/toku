package fr.lille1.univ.coo.tp.utils;

public class Constantes {
	
	public static final String CHEMIN_LOGO = "/logo.png";
	public static final String CHEMIN_APP_ICONE = "/icone.png";
	public static final String CHEMIN_VOIR_MDP = "/voirmdp.png";
	public static final String CHEMIN_CADRE_AVATAR = "/cadre_avatar.png";
	public static final String CHEMIN_NO_AVATAR = "/no_avatar.png";

}
