package fr.lille1.univ.coo.tp.cryptage;

public interface Crypteur {
	public String crypter(String texte) throws CryptageException;

}
