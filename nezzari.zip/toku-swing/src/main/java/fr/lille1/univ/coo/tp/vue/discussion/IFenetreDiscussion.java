package fr.lille1.univ.coo.tp.vue.discussion;

public interface IFenetreDiscussion {
	public void envoyer();

}
