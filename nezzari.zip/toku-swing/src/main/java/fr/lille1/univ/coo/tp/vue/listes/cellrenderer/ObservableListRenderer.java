package fr.lille1.univ.coo.tp.vue.listes.cellrenderer;

import javax.swing.ListCellRenderer;

public interface ObservableListRenderer<T> extends ListCellRenderer<T> {

}
