package fr.lille1.univ.coo.tp.vue.composants.fenetre;

public interface Fermable {
	public void fermer();

}
